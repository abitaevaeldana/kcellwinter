
from django.shortcuts import render, get_object_or_404
from django.views.generic import ListView, DetailView
from .models import Book, Review

class BookListView(ListView):
    model = Book
    template_name = 'books/book_list.html'

class BookDetailView(DetailView):
    model = Book
    template_name = 'books/book_detail.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['is_favorite'] = self.object.is_favorite(self.request.user)
        return context
